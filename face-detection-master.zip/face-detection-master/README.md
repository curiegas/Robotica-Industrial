AI Face Detection with webcam.
Based on Python & OpenCV